from django.contrib import admin

from .models import Mapname

admin.site.register(Mapname)

# Register your models here.
